#ifndef ACE_ENV_VALUE_T_CPP
#define ACE_ENV_VALUE_T_CPP

#include "ace/Env_Value_T.h"

#if ! defined (__ACE_INLINE__)
#include "ace/Env_Value_T.inl"
#endif /* __ACE_INLINE__ */

#endif /* ACE_ENV_VALUE_T_CPP */
